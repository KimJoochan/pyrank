#excel.py
from itertools import count
from lib2to3 import refactor
from openpyxl import Workbook

#load
import pandas as pd
def findFile(filename):
    df = pd.read_excel(filename)
    return df['keyword'].tolist()

#search
import sys
import io
import time

sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding = 'utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.detach(), encoding = 'utf-8')


#검색하기
import urllib.parse
import urllib.request
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager


from bs4 import BeautifulSoup
def search(keyword):
    title=""
    j=1
    hrefStr=""
    mainsub=""
    title_fv=""
    hrefStr_fv=""
    mainsub_fv=""
    i=0
    once = True
    
    adCnt=0 #광고개수구하기
    brandCnt=0 #브랜드개수 구하기
    cheerestCnt=0 #쇼핑몰 최저가 개수 구하기
    ectCnt=0 #아무것도 아닌 것
    while(True):
        baseUrl="https://search.shopping.naver.com/search/all?frm=NVSHATC&pagingIndex="+str(j)+"&pagingSize=40&productSet=total&query="
        url=baseUrl+urllib.parse.quote_plus(keyword)
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_argument('headless')
        driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
        
        driver.get(url)
        driver.implicitly_wait(10)
        time.sleep(2)
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight)")
        driver.implicitly_wait(10)
        time.sleep(1)
        soup=BeautifulSoup(driver.page_source,'html.parser')
        
        driver.quit()
        li_item=soup.select(".list_basis>div>div")
        cnt=0
        for item in li_item:
            if(len(item.select('.ad_ad_stk__12U34'))>=1) :
                if(once):
                    adCnt=adCnt+1
            elif(item.select_one('.basicList_mall_title__3MWFY a').text.find("쇼핑몰별 최저가")>=0):
                if(once):
                    cheerestCnt=cheerestCnt+1
            elif(item.select_one('.basicList_mall_title__3MWFY a').text.find("브랜드 카탈로그")>=0):
                if(once):
                    brandCnt=brandCnt+1
            elif(len(item.select('.ad_ad_stk__12U34'))==0):
                ectCnt=ectCnt+1
                if(i>=5): #베스트 5개를
                    continue
                anchor=item.select_one('.basicList_title__3P9Q7 a')
                href=anchor.attrs["href"]
                hrefStr=hrefStr+"====="+href
                title=title+"====="+anchor.text
                txt=""
                if(title.find(keyword)>=0):
                    txt="메인"
                else:
                    txt="서브"
                mainsub=mainsub+"====="+txt
                i=i+1
       
        title_fv=title[5:]
        hrefStr_fv=hrefStr[5:]
        mainsub_fv=mainsub[5:]
        totalCnt = len(mainsub_fv.split('====='))
        j=j+1 #임시 방편 커트하기 위한 것
        if(j>=5):
            break
        if(totalCnt>=5):
            break
        once = False #첫번째로 실행한 결과값에서 광고가 몇개,브랜드가 몇개,쇼핑몰 최저가가 몇개인지 확인 하기 위한것
    addCntStr="광고 개수 : "+str(adCnt)
    brandCntStr="브랜드 개수 : "+str(brandCnt)
    cheerestCntStr="쇼핑몰 최저가 개수 : "+str(cheerestCnt)
    ectCntStr="아무것도 아닌 것 개수 : "+str(ectCnt)
    
    dic={'title':title_fv,'href':hrefStr_fv,'mainsub':mainsub_fv,'addCntStr':addCntStr,'brandCntStr':brandCntStr,'cheerestCntStr':cheerestCntStr,'ectCntStr':ectCntStr}
    return dic

#refacory
def make_data(keyword,item):
    result=[]
    result.append(keyword)
    title=want_str(item['title'])
    href=want_str(item['href'])
    hashTagStr=hashTag(item['href'])
    hash=want_str(hashTagStr)
    mainsub=want_str(item['mainsub'])
    result.append(title)
    result.append(href)
    result.append(mainsub)
    result.append(item['addCntStr'])
    result.append(item['brandCntStr'])
    result.append(item['cheerestCntStr'])
    result.append(item['ectCntStr'])
    result.append(hash[1:])
    return result

#구분자(=====)을 ,로 바꾸는 작업
def want_str(str_item):
    str_obj=str_item.split('=====')
    cnt=0
    refact=""
    for item in str_obj:
        if(cnt==0):
            refact=item
        else:
            refact=refact+","+item
        cnt=cnt+1
    return refact

def hashTag(hrefStr):
    hrefObj=hrefStr.split('=====')
    hashStr=""
    for url in hrefObj:
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_argument('headless')
        driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
        driver.get(url)
        driver.implicitly_wait(10)
        time.sleep(2)
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight)")
        driver.implicitly_wait(10)
        time.sleep(1)
        soup=BeautifulSoup(driver.page_source,'html.parser')
        driver.quit()
        li_item=soup.select("._3Vox1DKZiA li")
        for item in li_item:
            hashTxt=item.select_one('a').text
            hashStr=hashStr+"====="+hashTxt
            
    return hashStr

# 엑셀파일 쓰기
def make_excel_file(excel_list):
    write_wb = Workbook()
    # 이름이 있는 시트를 생성
    # Sheet1에다 입력
    write_ws = write_wb.active
    write_ws.append(['keyword','제목'])
    for item in excel_list:
        write_ws.append(item)
    write_wb.save("search.xlsx")

list_txt=findFile('search.xlsx')
excel_list=[]
for keyword in list_txt:
    li_item=search(keyword)
    result_list=make_data(keyword,li_item)
    excel_list.append(result_list)
make_excel_file(excel_list)
